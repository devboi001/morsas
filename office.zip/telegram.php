
<?php

$botToken = "5203184179:AAGi4A1afZyLIzsxvV0CPsjuHRJ3d89tR9E";

$id = "5009918391";

?>